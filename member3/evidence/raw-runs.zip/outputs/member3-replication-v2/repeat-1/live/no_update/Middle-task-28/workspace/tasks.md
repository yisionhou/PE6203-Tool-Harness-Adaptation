# Tasks - Tasks

## In Progress


## To Do

- [ ] Investigate persistent low disk space warning (present in both log_yesterday.txt and log_today.txt) and free up disk space / clean up old logs
- [ ] Monitor database connection stability (failed yesterday in log_yesterday.txt, no error today) and verify the issue is fully resolved
- [ ] Add disk space monitoring/alerting so low-space conditions are caught and addressed before escalating to an error

## Backlog


## Done
