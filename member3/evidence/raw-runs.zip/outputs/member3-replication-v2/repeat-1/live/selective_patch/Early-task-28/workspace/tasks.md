# Tasks - Tasks

## In Progress


## To Do

- [ ] Investigate and resolve persistent 'Disk space low' warning (appears in both yesterday's and today's logs) - check disk usage, clear old logs/artifacts, or expand storage.
- [ ] Verify the 'Database connection failed' error from yesterday is truly resolved (no error appears in today's log) - test DB connectivity and restart services if needed.

## Backlog


## Done
