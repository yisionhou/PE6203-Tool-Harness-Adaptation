# Tasks - Tasks

## In Progress


## To Do

- [ ] Investigate and resolve low disk space warning - [WARN] Disk space low persists in today's log (also present yesterday)
- [ ] Verify database connectivity is healthy - [ERROR] Database connection failed appeared in yesterday's log but is absent today; confirm root cause is resolved
- [ ] Check whether user login activity is expected - [INFO] User logged in appears in yesterday's log but not today; confirm no login issue/outage

## Backlog


## Done
