# Tasks - Logs Tasks

## In Progress


## To Do

- [ ] Investigate low disk space warning: check disk usage and identify large/unnecessary files for cleanup
- [ ] Free up disk space: clean temporary files and old logs to resolve the 'Disk space low' warning
- [ ] Diagnose database connection failure: check DB credentials, network connectivity, and service status (port 3305)
- [ ] Restart or reconfigure the database service to restore the failed connection
- [ ] Verify service health after fixes: confirm service starts cleanly with no WARN/ERROR entries in logs
- [ ] Set up monitoring/alerting for disk usage and database connection to prevent recurrence

## Backlog


## Done
