# Tasks - Logs Tasks

## In Progress


## To Do

- [ ] Investigate disk space usage and identify what is consuming storage (Disk space low warning)
- [ ] Free up disk space by clearing logs, temp files, or unused data and confirm headroom
- [ ] Set up disk space monitoring/alerting threshold so future low-space warnings are caught early
- [ ] Diagnose the database connection failure (check DB service status, credentials, and network connectivity)
- [ ] Restart the database service and verify connectivity is restored
- [ ] Run an end-to-end check that the service operates correctly after fixes (no new ERROR/WARN entries)
- [ ] Review recent logs for recurring issues and document any patterns for follow-up

## Backlog


## Done
