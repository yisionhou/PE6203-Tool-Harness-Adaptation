# Tasks - Logs Tasks

## In Progress


## To Do

- [ ] Investigate low disk space warning: check current disk usage and identify what is consuming space
- [ ] Free up disk space by cleaning up logs/temp files and ensure above the safety threshold
- [ ] Investigate database connection failure: check DB service status and connectivity settings
- [ ] Fix database connection: restart/verify database service and confirm connection is restored
- [ ] Verify system health after fixes: confirm no WARN/ERROR entries appear in the latest logs

## Backlog


## Done
