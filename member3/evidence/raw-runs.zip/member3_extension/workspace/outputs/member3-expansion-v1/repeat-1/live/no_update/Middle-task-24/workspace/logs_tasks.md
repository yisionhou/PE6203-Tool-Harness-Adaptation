# Tasks - Logs Tasks

## In Progress


## To Do

- [ ] Investigate disk usage and free up disk space (log: WARN Disk space low)
- [ ] Diagnose and fix the database connection failure (log: ERROR Database connection failed) - verify DB service is running and credentials are valid
- [ ] Restart database service if needed and confirm connectivity is restored
- [ ] Add disk space monitoring/alert threshold to prevent recurrence

## Backlog


## Done
