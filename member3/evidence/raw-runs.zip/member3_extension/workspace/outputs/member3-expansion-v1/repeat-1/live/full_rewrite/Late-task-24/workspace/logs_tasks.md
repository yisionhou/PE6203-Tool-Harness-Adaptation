# Tasks - Logs Tasks

## In Progress


## To Do

- [ ] Investigate database connection failure - verify DB service (127.0.0.1:3305) is running and credentials are valid
- [ ] Restart the database service and confirm the connection is successfully re-established
- [ ] Free up disk space - identify and remove large, temporary, or outdated files/logs from the workspace
- [ ] Set up disk space monitoring/alerting so low-disk warnings are caught before they become errors
- [ ] Verify the service starts cleanly and confirm the user login flow works end-to-end after the fixes

## Backlog


## Done
