# Tasks - Logs Tasks

## In Progress


## To Do

- [ ] Investigate disk space usage and identify which files/directories are consuming the most space
- [ ] Free up disk space (e.g., clean temp files, archive/rotate old logs) and confirm free space is above threshold
- [ ] Diagnose the database connection failure: check DB service status and verify it is running
- [ ] Verify database credentials and connection settings (host, port, user, password, database name) in the configuration
- [ ] Test and restore the database connection, then confirm the application can connect successfully
- [ ] Restart the application service and verify it starts cleanly with no errors in today's log

## Backlog


## Done
