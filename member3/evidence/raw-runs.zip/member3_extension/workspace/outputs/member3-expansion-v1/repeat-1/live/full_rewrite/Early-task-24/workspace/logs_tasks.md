# Tasks - Logs Tasks

## In Progress


## To Do

- [ ] Investigate disk space usage and free up space (warning: 'Disk space low')
- [ ] Troubleshoot and fix database connection failure (error: 'Database connection failed')

## Backlog


## Done
