# Tasks - Logs Tasks

## In Progress


## To Do

- [ ] Investigate disk space usage and free up space on the server (flagged by [WARN] Disk space low in yesterday's log)
- [ ] Diagnose and resolve the database connection failure (flagged by [ERROR] Database connection failed in yesterday's log)

## Backlog


## Done
